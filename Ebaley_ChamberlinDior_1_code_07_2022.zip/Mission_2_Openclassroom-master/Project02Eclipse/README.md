Sample project for OpenClassroom's fundamentals of Java
