package com.hemebiotech.analytics;

import java.util.List;
import java.util.Map;

public interface ISymptomsCompute {
    Map<String,Integer> getMapFromList(List<String> symptomList) ;
}

